//
//  ExploreSearchBarView.swift
//  Roami
//
//  The pill-shaped search field + user avatar row at the top of Explore.
//

import SwiftUI

struct ExploreSearchBarView: View {
    @Binding var text: String

    var body: some View {
        HStack(spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(RoamiTheme.sageGreen)

                TextField("Search destinations...", text: $text)
                    .textFieldStyle(.plain)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(Color(.secondarySystemBackground))
            .clipShape(Capsule())

            ProfileAvatarLink()
        }
    }
}

#Preview {
    NavigationStack {
        ExploreSearchBarView(text: .constant(""))
            .padding()
    }
}
