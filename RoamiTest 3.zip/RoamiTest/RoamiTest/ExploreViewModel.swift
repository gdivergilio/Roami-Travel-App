//
//  ExploreViewModel.swift
//  Roami
//
//  Owns the data shown on the Explore screen. Currently seeded with
//  placeholder data matching the Hi-Fi; swap `loadDestinations()` for
//  a real network/service call when the backend is ready — the view
//  itself won't need to change.
//

import Foundation
import Combine

@MainActor
final class ExploreViewModel: ObservableObject {
    @Published var searchText: String = ""
    @Published var trending: [Destination] = []
    @Published var exploreGrid: [Destination] = []
    @Published var isLoading: Bool = false

    /// Destinations found by the global (Wikipedia) lookup for the
    /// current search text — lets users search any country or city,
    /// not just the curated catalog.
    @Published var globalSearchResults: [Destination] = []

    /// Grid filtered by search text; falls back to full grid when empty.
    /// Searching matches destination name OR country across *all*
    /// destinations (trending included), so typing e.g. "Japan" surfaces
    /// both Kyoto and Shibuya — plus any global lookup results that
    /// aren't already covered by the catalog.
    var filteredExploreGrid: [Destination] {
        guard !searchText.isEmpty else { return exploreGrid }
        let local = (trending + exploreGrid).filter {
            $0.name.localizedCaseInsensitiveContains(searchText) ||
            $0.country.localizedCaseInsensitiveContains(searchText)
        }
        let remote = globalSearchResults.filter { result in
            !local.contains { $0.name.caseInsensitiveCompare(result.name) == .orderedSame }
        }
        return local + remote
    }

    /// Looks the search text up on Wikipedia (free, no API key) and turns
    /// the page summary into a Destination: title, description, blurb,
    /// thumbnail photo and coordinates. Works for any country or city.
    func searchGlobalDestination() async {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard query.count >= 3 else {
            globalSearchResults = []
            return
        }

        let page = query.replacingOccurrences(of: " ", with: "_")
        guard let encoded = page.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "https://en.wikipedia.org/api/rest_v1/page/summary/\(encoded)") else {
            globalSearchResults = []
            return
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let summary = try JSONDecoder().decode(WikiSummary.self, from: data)

            // Places only — this is a travel search, not an encyclopedia.
            // Two gates: the article must be geotagged (objects like
            // "t-shirt" have no coordinates), and its description must
            // identify it as a country/city/region-type place.
            guard summary.type == "standard",
                  let description = summary.description,
                  summary.coordinates != nil,
                  Self.isPlace(description) else {
                globalSearchResults = []
                return
            }
            // Bail if the text changed while we were fetching.
            guard searchText.trimmingCharacters(in: .whitespacesAndNewlines) == query else { return }

            globalSearchResults = [
                Destination(
                    name: summary.title,
                    country: description,
                    imageURL: summary.thumbnail?.source,
                    blurb: summary.extract.map { String($0.prefix(while: { $0 != "." })) + "." },
                    riskLevel: .moderate, // default until a real safety feed exists
                    latitude: summary.coordinates?.lat,
                    longitude: summary.coordinates?.lon
                )
            ]
        } catch {
            globalSearchResults = []
        }
    }

    /// Wikipedia's one-line description for geographic articles almost
    /// always names the kind of place ("Country in Western Europe",
    /// "City in Kansai, Japan", "State of the United States", ...).
    private static let placeKeywords = [
        "country", "city", "town", "village", "capital", "state",
        "province", "region", "island", "municipality", "prefecture",
        "territory", "district", "county", "commune", "settlement",
        "archipelago", "metropolis"
    ]

    private static func isPlace(_ description: String) -> Bool {
        let lowered = description.lowercased()
        return placeKeywords.contains { lowered.contains($0) }
    }

    private struct WikiSummary: Decodable {
        struct Thumbnail: Decodable { let source: URL }
        struct Coordinates: Decodable { let lat: Double; let lon: Double }

        let title: String
        let type: String?
        let description: String?
        let extract: String?
        let thumbnail: Thumbnail?
        let coordinates: Coordinates?
    }

    func loadDestinations() {
        isLoading = true
        // Placeholder data mirroring the Hi-Fi (see Destination.sample*).
        // Replace with a real async fetch later. Pin state lives in
        // FavoritesStore, not here.
        trending = Destination.sampleTrending
        exploreGrid = Destination.sampleExploreGrid
        isLoading = false
    }
}
