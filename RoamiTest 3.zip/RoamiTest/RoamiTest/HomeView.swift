//
//  HomeView.swift
//  Roami
//
//  The Home tab: "Where to next?" header, an interactive 3D globe
//  (SceneKit — see GlobeSceneContainer.swift for why not MapKit), and
//  the circular "PIN" action button beneath it.
//
//  Replaces the earlier placeholder now that this screen is real.
//

import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var favorites: FavoritesStore

    /// Pins currently shown on the globe (the user's favorites, revealed
    /// by the PIN button). Kept as @State so pin identities stay stable
    /// across the per-frame position updates.
    @State private var pins: [GlobePin] = []
    @State private var showPins = false

    @State private var pinScreenPositions: [UUID: CGPoint] = [:]
    @State private var pinVisibility: [UUID: Bool] = [:]

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                header
                    .padding(.horizontal, 20)
                    .padding(.top, 8)

                Spacer(minLength: 16)

                globe
                    .aspectRatio(1, contentMode: .fit)
                    .padding(.horizontal, 12)

                pinToggle
                    .padding(.top, 12)

                Spacer(minLength: 16)
            }
            .background(RoamiTheme.background.ignoresSafeArea())
            .navigationDestination(for: Destination.self) { destination in
                DestinationDetailView(destination: destination)
            }
            .onChange(of: favorites.favorites) {
                syncPins()
            }
        }
    }

    /// Rebuilds the globe pins from the favorites list (or clears them
    /// when pins are hidden).
    private func syncPins() {
        guard showPins else {
            pins = []
            return
        }
        pins = favorites.favorites.compactMap { destination in
            guard let latitude = destination.latitude, let longitude = destination.longitude else { return nil }
            return GlobePin(name: destination.name, latitude: latitude, longitude: longitude)
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Welcome, Jean-Paul")
                    .font(.subheadline)
                    .foregroundStyle(RoamiTheme.sageGreen)
                Text("Where to next?")
                    .font(.largeTitle.weight(.bold))
                    .foregroundStyle(RoamiTheme.deepGreen)
            }
            Spacer()
            ProfileAvatarLink(size: 40)
        }
    }

    // MARK: - Globe + overlaid pin labels

    private var globe: some View {
        ZStack {
            GlobeSceneContainer(pins: pins) { positions, visible in
                pinScreenPositions = positions
                pinVisibility = visible
            }

            ForEach(pins) { pin in
                if pinVisibility[pin.id] == true, let position = pinScreenPositions[pin.id] {
                    // Name tags link to the destination's summary page.
                    if let destination = favorites.destination(named: pin.name) {
                        NavigationLink(value: destination) {
                            GlobePinLabelView(name: pin.name)
                        }
                        .buttonStyle(.plain)
                        .position(position)
                    } else {
                        GlobePinLabelView(name: pin.name)
                            .position(position)
                            .allowsHitTesting(false)
                    }
                }
            }
        }
    }

    // MARK: - PIN button

    /// Dual-panel horizontal switch: Show Pins (green) / Hide Pins (rust).
    private var pinToggle: some View {
        HStack(spacing: 0) {
            pinToggleSegment(
                label: "Show Pins",
                systemImage: "mappin",
                isActive: showPins,
                activeColor: RoamiTheme.deepGreen
            ) {
                setShowPins(true)
            }
            pinToggleSegment(
                label: "Hide Pins",
                systemImage: "mappin.slash",
                isActive: !showPins,
                activeColor: RoamiTheme.rust
            ) {
                setShowPins(false)
            }
        }
        .padding(4)
        .background(.white, in: Capsule())
        .shadow(color: .black.opacity(0.15), radius: 5, y: 3)
    }

    private func pinToggleSegment(
        label: String,
        systemImage: String,
        isActive: Bool,
        activeColor: Color,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            HStack(spacing: 5) {
                Image(systemName: systemImage)
                    .font(.caption.weight(.bold))
                Text(label)
                    .font(.caption.weight(.bold))
            }
            .foregroundStyle(isActive ? .white : .secondary)
            .padding(.horizontal, 16)
            .padding(.vertical, 9)
            .background(isActive ? activeColor : .clear, in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func setShowPins(_ show: Bool) {
        guard showPins != show else { return }
        withAnimation(.spring(duration: 0.3)) {
            showPins = show
        }
        syncPins()
    }
}

#Preview {
    HomeView()
        .environmentObject(FavoritesStore())
}
